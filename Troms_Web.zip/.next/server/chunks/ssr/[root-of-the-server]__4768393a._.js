module.exports = {

"[project]/Components/DesiredWeightPicker.js [app-ssr] (ecmascript)": ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s({
    "default": ()=>__TURBOPACK__default__export__
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react.js [app-ssr] (ecmascript)");
"use client";
;
;
const DesiredWeightPicker = ({ weight: externalWeight = 75, isMetric = true, onChange, minWeight = null, maxWeight = null, currentWeight = null, weightGoal = null, currentWeightUnit = null, disabled = false })=>{
    // Use provided min/max or default based on unit
    const defaultMinWeight = isMetric ? 30 : 60;
    const defaultMaxWeight = isMetric ? 300 : 600;
    const min = minWeight !== null && minWeight !== undefined ? minWeight : defaultMinWeight;
    const max = maxWeight !== null && maxWeight !== undefined ? maxWeight : defaultMaxWeight;
    const [weight, setWeight] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(()=>{
        // Ensure initial weight is within min/max range
        return Math.max(min, Math.min(max, externalWeight));
    });
    const [dragging, setDragging] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(false);
    const pickerRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useRef"])(null);
    // Update internal state when external weight changes
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEffect"])(()=>{
        const clampedWeight = Math.max(min, Math.min(max, externalWeight));
        setWeight(clampedWeight);
    }, [
        externalWeight,
        min,
        max
    ]);
    // Clamp weight to min/max range when range changes
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEffect"])(()=>{
        if (weight < min || weight > max) {
            const clampedWeight = Math.max(min, Math.min(max, weight));
            setWeight(clampedWeight);
            if (onChange) onChange(clampedWeight);
        }
    }, [
        min,
        max,
        weight,
        onChange
    ]);
    // Cleanup function to remove event listeners
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEffect"])(()=>{
        return ()=>{
            // Cleanup any remaining event listeners
            document.removeEventListener("pointermove", handlePointerMove);
            document.removeEventListener("pointerup", handlePointerUp);
            document.removeEventListener("touchmove", handleTouchMove);
            document.removeEventListener("touchend", handlePointerUp);
        };
    }, []);
    // Calculate the number of ticks between min and max
    const totalTicks = (max - min) * 4; // quarter steps (0.25)
    // Convert weight to position in pixels within the slider
    const getPosFromWeight = (weightVal)=>{
        const pickerWidth = pickerRef.current ? pickerRef.current.clientWidth : 0;
        const relativeWeight = (weightVal - min) / (max - min);
        return relativeWeight * pickerWidth;
    };
    // Convert position in pixels to weight value
    const getWeightFromPos = (pos)=>{
        const pickerWidth = pickerRef.current ? pickerRef.current.clientWidth : 0;
        const relativePos = Math.min(Math.max(pos, 0), pickerWidth) / pickerWidth;
        // Round to nearest 0.25
        return Math.round((min + relativePos * (max - min)) * 4) / 4;
    };
    const handlePointerDown = (e)=>{
        if (disabled) return; // Don't handle events when disabled
        e.preventDefault();
        setDragging(true);
        moveHandle(e);
        // Add global listeners for smooth dragging
        document.addEventListener("pointermove", handlePointerMove);
        document.addEventListener("pointerup", handlePointerUp);
        document.addEventListener("touchmove", handleTouchMove);
        document.addEventListener("touchend", handlePointerUp);
    };
    const handlePointerMove = (e)=>{
        if (!dragging) return;
        e.preventDefault();
        moveHandle(e);
    };
    const handleTouchMove = (e)=>{
        if (!dragging) return;
        e.preventDefault();
        moveHandle(e.touches[0]);
    };
    const handlePointerUp = ()=>{
        setDragging(false);
        // Remove global listeners
        document.removeEventListener("pointermove", handlePointerMove);
        document.removeEventListener("pointerup", handlePointerUp);
        document.removeEventListener("touchmove", handleTouchMove);
        document.removeEventListener("touchend", handlePointerUp);
    };
    const moveHandle = (e)=>{
        if (!pickerRef.current) return;
        const bounds = pickerRef.current.getBoundingClientRect();
        const clientX = e.clientX || (e.touches && e.touches[0] ? e.touches[0].clientX : 0);
        let posX = clientX - bounds.left;
        let newWeight = getWeightFromPos(posX);
        // Ensure weight is within bounds
        newWeight = Math.max(min, Math.min(max, newWeight));
        setWeight(newWeight);
        if (onChange) onChange(newWeight);
    };
    // Keyboard navigation support
    const handleKeyDown = (e)=>{
        if (disabled) return; // Don't handle events when disabled
        if (e.key === "ArrowLeft" || e.key === "ArrowDown") {
            const newWeight = Math.max(min, Math.round((weight - 0.25) * 4) / 4);
            setWeight(newWeight);
            if (onChange) onChange(newWeight);
        } else if (e.key === "ArrowRight" || e.key === "ArrowUp") {
            const newWeight = Math.min(max, Math.round((weight + 0.25) * 4) / 4);
            setWeight(newWeight);
            if (onChange) onChange(newWeight);
        }
    };
    // Calculate weight difference and percentage
    const calculateWeightStats = ()=>{
        if (!currentWeight || !weightGoal) {
            return {
                difference: 0,
                percentage: 0,
                show: false
            };
        }
        // Convert current weight to display unit for consistent calculation
        let currentWeightInDisplayUnit = currentWeight;
        if (currentWeightUnit === 'kg' && !isMetric) {
            // Convert kg to lbs
            currentWeightInDisplayUnit = currentWeight / 0.453592;
        } else if (currentWeightUnit === 'lbs' && isMetric) {
            // Convert lbs to kg
            currentWeightInDisplayUnit = currentWeight * 0.453592;
        }
        const difference = Math.abs(weight - currentWeightInDisplayUnit);
        const percentage = currentWeightInDisplayUnit > 0 ? difference / currentWeightInDisplayUnit * 100 : 0;
        return {
            difference: Math.round(difference * 10) / 10,
            percentage: Math.round(percentage * 10) / 10,
            show: difference > 0 && weightGoal !== 'MAINTAIN',
            isLoss: weight < currentWeightInDisplayUnit,
            isGain: weight > currentWeightInDisplayUnit
        };
    };
    const getWeightChangeText = ()=>{
        const stats = calculateWeightStats();
        if (!stats.show) return null;
        const unit = isMetric ? 'Kg' : 'lbs';
        let difficultyText = '';
        let actionText = '';
        if (stats.isLoss) {
            actionText = 'lose';
            // Determine difficulty based on percentage
            if (stats.percentage >= 15) {
                difficultyText = 'Very hard to';
            } else if (stats.percentage >= 10) {
                difficultyText = 'Hard to';
            } else if (stats.percentage >= 5) {
                difficultyText = 'Moderate to';
            } else {
                difficultyText = 'Easy to';
            }
        } else if (stats.isGain) {
            actionText = 'gain';
            // Determine difficulty for weight gain
            if (stats.percentage >= 10) {
                difficultyText = 'Challenging to';
            } else if (stats.percentage >= 5) {
                difficultyText = 'Moderate to';
            } else {
                difficultyText = 'Easy to';
            }
        }
        return {
            primaryText: `${difficultyText} ${actionText}`,
            weightText: `${stats.difference} ${unit}`,
            secondaryText: `You will ${actionText} ${stats.percentage}% of body weight!`
        };
    };
    // Generate tick marks
    const renderTicks = ()=>{
        const ticks = [];
        // 4 ticks per number: 0.25 divisions; long ticks every 1 unit
        for(let i = 0; i <= totalTicks; i++){
            const tickWeight = min + i * 0.25;
            const isLongTick = i % 4 === 0;
            const isMediumTick = i % 2 === 0 && !isLongTick;
            ticks.push(/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: `tick ${isLongTick ? "long" : isMediumTick ? "medium" : "short"}`,
                style: {
                    left: `${i / totalTicks * 100}%`
                }
            }, i, false, {
                fileName: "[project]/Components/DesiredWeightPicker.js",
                lineNumber: 215,
                columnNumber: 9
            }, ("TURBOPACK compile-time value", void 0)));
        }
        return ticks;
    };
    // Render the numbers visible above the slider (two left, current, two right)
    const renderNumbers = ()=>{
        const numbers = [];
        for(let offset = -2; offset <= 2; offset++){
            let number = Math.round((weight + offset) * 1) / 1; // Keep integer for display
            // Only display numbers inside range
            if (number >= min && number <= max) {
                let className = "number";
                if (offset === 0) className += " current";
                else if (Math.abs(offset) === 1) className += " near";
                else className += " far";
                numbers.push(/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                    className: className,
                    style: {
                        left: `${50 + offset * 25}%`
                    },
                    children: number
                }, number, false, {
                    fileName: "[project]/Components/DesiredWeightPicker.js",
                    lineNumber: 239,
                    columnNumber: 11
                }, ("TURBOPACK compile-time value", void 0)));
            }
        }
        return numbers;
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Fragment"], {
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "weight-picker-container trm-wgt-picker",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "numbers-wrapper",
                    children: renderNumbers()
                }, void 0, false, {
                    fileName: "[project]/Components/DesiredWeightPicker.js",
                    lineNumber: 254,
                    columnNumber: 9
                }, ("TURBOPACK compile-time value", void 0)),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: `slider ${disabled ? 'disabled' : ''}`,
                    ref: pickerRef,
                    onPointerDown: disabled ? undefined : handlePointerDown,
                    onTouchStart: disabled ? undefined : handlePointerDown,
                    onKeyDown: disabled ? undefined : handleKeyDown,
                    tabIndex: disabled ? -1 : 0,
                    role: "slider",
                    "aria-valuemin": min,
                    "aria-valuemax": max,
                    "aria-valuenow": weight,
                    "aria-label": "Weight picker",
                    "aria-disabled": disabled,
                    style: {
                        touchAction: "none",
                        opacity: disabled ? 0.5 : 1,
                        cursor: disabled ? 'not-allowed' : 'grab'
                    },
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "ticks-wrapper",
                            children: renderTicks()
                        }, void 0, false, {
                            fileName: "[project]/Components/DesiredWeightPicker.js",
                            lineNumber: 276,
                            columnNumber: 11
                        }, ("TURBOPACK compile-time value", void 0)),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "middle-line"
                        }, void 0, false, {
                            fileName: "[project]/Components/DesiredWeightPicker.js",
                            lineNumber: 279,
                            columnNumber: 11
                        }, ("TURBOPACK compile-time value", void 0)),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "pointer",
                            style: {
                                left: `${(weight - min) / (max - min) * 100}%`
                            }
                        }, void 0, false, {
                            fileName: "[project]/Components/DesiredWeightPicker.js",
                            lineNumber: 282,
                            columnNumber: 11
                        }, ("TURBOPACK compile-time value", void 0)),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                            className: "bottom-triangle",
                            style: {
                                left: `${(weight - min) / (max - min) * 100}%`
                            }
                        }, void 0, false, {
                            fileName: "[project]/Components/DesiredWeightPicker.js",
                            lineNumber: 289,
                            columnNumber: 11
                        }, ("TURBOPACK compile-time value", void 0))
                    ]
                }, void 0, true, {
                    fileName: "[project]/Components/DesiredWeightPicker.js",
                    lineNumber: 256,
                    columnNumber: 9
                }, ("TURBOPACK compile-time value", void 0)),
                (()=>{
                    const weightChangeText = getWeightChangeText();
                    return weightChangeText ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "desired-lose-bx",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("h5", {
                                children: [
                                    weightChangeText.primaryText,
                                    " - ",
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        children: weightChangeText.weightText
                                    }, void 0, false, {
                                        fileName: "[project]/Components/DesiredWeightPicker.js",
                                        lineNumber: 301,
                                        columnNumber: 50
                                    }, ("TURBOPACK compile-time value", void 0))
                                ]
                            }, void 0, true, {
                                fileName: "[project]/Components/DesiredWeightPicker.js",
                                lineNumber: 300,
                                columnNumber: 15
                            }, ("TURBOPACK compile-time value", void 0)),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("h6", {
                                children: weightChangeText.secondaryText
                            }, void 0, false, {
                                fileName: "[project]/Components/DesiredWeightPicker.js",
                                lineNumber: 303,
                                columnNumber: 15
                            }, ("TURBOPACK compile-time value", void 0))
                        ]
                    }, void 0, true, {
                        fileName: "[project]/Components/DesiredWeightPicker.js",
                        lineNumber: 299,
                        columnNumber: 13
                    }, ("TURBOPACK compile-time value", void 0)) : null;
                })(),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "selected-weight",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                            className: "weight-number",
                            children: weight.toFixed(weight % 1 === 0 ? 0 : 2)
                        }, void 0, false, {
                            fileName: "[project]/Components/DesiredWeightPicker.js",
                            lineNumber: 309,
                            columnNumber: 11
                        }, ("TURBOPACK compile-time value", void 0)),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                            className: "weight-unit",
                            children: isMetric ? "Kg" : "lbs"
                        }, void 0, false, {
                            fileName: "[project]/Components/DesiredWeightPicker.js",
                            lineNumber: 312,
                            columnNumber: 11
                        }, ("TURBOPACK compile-time value", void 0))
                    ]
                }, void 0, true, {
                    fileName: "[project]/Components/DesiredWeightPicker.js",
                    lineNumber: 308,
                    columnNumber: 9
                }, ("TURBOPACK compile-time value", void 0))
            ]
        }, void 0, true, {
            fileName: "[project]/Components/DesiredWeightPicker.js",
            lineNumber: 253,
            columnNumber: 7
        }, ("TURBOPACK compile-time value", void 0))
    }, void 0, false);
};
const __TURBOPACK__default__export__ = DesiredWeightPicker;
}),
"[externals]/next/dist/server/app-render/work-async-storage.external.js [external] (next/dist/server/app-render/work-async-storage.external.js, cjs)": ((__turbopack_context__) => {

var { m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("next/dist/server/app-render/work-async-storage.external.js", () => require("next/dist/server/app-render/work-async-storage.external.js"));

module.exports = mod;
}}),
"[externals]/next/dist/server/app-render/action-async-storage.external.js [external] (next/dist/server/app-render/action-async-storage.external.js, cjs)": ((__turbopack_context__) => {

var { m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("next/dist/server/app-render/action-async-storage.external.js", () => require("next/dist/server/app-render/action-async-storage.external.js"));

module.exports = mod;
}}),
"[externals]/next/dist/server/app-render/work-unit-async-storage.external.js [external] (next/dist/server/app-render/work-unit-async-storage.external.js, cjs)": ((__turbopack_context__) => {

var { m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("next/dist/server/app-render/work-unit-async-storage.external.js", () => require("next/dist/server/app-render/work-unit-async-storage.external.js"));

module.exports = mod;
}}),
"[project]/Components/Alert.js [app-ssr] (ecmascript)": ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s({
    "default": ()=>Alert
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react.js [app-ssr] (ecmascript)");
'use client';
;
;
function Alert({ type = 'info', message, show, onClose, autoClose = true, duration = 3000 }) {
    const [visible, setVisible] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(show);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEffect"])(()=>{
        setVisible(show);
        if (show && autoClose) {
            const timer = setTimeout(()=>{
                setVisible(false);
                if (onClose) onClose();
            }, duration);
            return ()=>clearTimeout(timer);
        }
    }, [
        show,
        autoClose,
        duration,
        onClose
    ]);
    if (!visible || !message) return null;
    const alertClasses = {
        success: 'alert-success',
        error: 'alert-danger',
        warning: 'alert-warning',
        info: 'alert-info'
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: `alert ${alertClasses[type]} alert-dismissible fade show`,
        role: "alert",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "d-flex align-items-center",
                children: [
                    type === 'success' && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                        className: "me-2",
                        children: "✅"
                    }, void 0, false, {
                        fileName: "[project]/Components/Alert.js",
                        lineNumber: 33,
                        columnNumber: 32
                    }, this),
                    type === 'error' && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                        className: "me-2",
                        children: "❌"
                    }, void 0, false, {
                        fileName: "[project]/Components/Alert.js",
                        lineNumber: 34,
                        columnNumber: 30
                    }, this),
                    type === 'warning' && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                        className: "me-2",
                        children: "⚠️"
                    }, void 0, false, {
                        fileName: "[project]/Components/Alert.js",
                        lineNumber: 35,
                        columnNumber: 32
                    }, this),
                    type === 'info' && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                        className: "me-2",
                        children: "ℹ️"
                    }, void 0, false, {
                        fileName: "[project]/Components/Alert.js",
                        lineNumber: 36,
                        columnNumber: 29
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                        children: message
                    }, void 0, false, {
                        fileName: "[project]/Components/Alert.js",
                        lineNumber: 37,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/Components/Alert.js",
                lineNumber: 32,
                columnNumber: 7
            }, this),
            onClose && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                type: "button",
                className: "btn-close",
                onClick: ()=>{
                    setVisible(false);
                    onClose();
                }
            }, void 0, false, {
                fileName: "[project]/Components/Alert.js",
                lineNumber: 40,
                columnNumber: 9
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/Components/Alert.js",
        lineNumber: 31,
        columnNumber: 5
    }, this);
}
}),
"[project]/app/(frontpage)/new-desired-weight/page.js [app-ssr] (ecmascript)": ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s({
    "default": ()=>__TURBOPACK__default__export__
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Components$2f$DesiredWeightPicker$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Components/DesiredWeightPicker.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/client/app-dir/link.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/navigation.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$context$2f$OnboardingContext$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/context/OnboardingContext.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Components$2f$Alert$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Components/Alert.js [app-ssr] (ecmascript)");
'use client';
;
;
;
;
;
;
;
function DesiredWeightPage() {
    const router = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useRouter"])();
    const { state, updateField, updateStep, isStepValid } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$context$2f$OnboardingContext$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useOnboarding"])();
    // Use global unit system
    const isMetric = state.unitSystem === "metric";
    // Convert current weight to display unit if needed
    const getCurrentWeightInDisplayUnit = ()=>{
        if (!state.weight) return 0;
        const currentWeight = state.weight;
        const currentWeightUnit = state.weightUnit;
        let displayWeight = currentWeight;
        if (currentWeightUnit === 'kg' && !isMetric) {
            // Convert kg to lbs for display
            displayWeight = Math.round(currentWeight / 0.453592 * 10) / 10;
        } else if (currentWeightUnit === 'lbs' && isMetric) {
            // Convert lbs to kg for display
            displayWeight = Math.round(currentWeight * 0.453592 * 10) / 10;
        }
        return displayWeight;
    };
    // Calculate dynamic min/max values based on weight goal
    const calculateMinMaxWeight = ()=>{
        const currentDisplayWeight = getCurrentWeightInDisplayUnit();
        if (!currentDisplayWeight || !state.weightGoal) {
            // Default fallback values
            return {
                min: isMetric ? 30 : 60,
                max: isMetric ? 300 : 600
            };
        }
        let minWeight, maxWeight;
        switch(state.weightGoal){
            case 'LOSE_WEIGHT':
                // For weight loss: min = current weight - 10, max = current weight - 1
                minWeight = Math.max(isMetric ? 30 : 60, Math.round((currentDisplayWeight - 10) * 4) / 4 // Current weight minus 10, rounded to 0.25
                );
                maxWeight = Math.round((currentDisplayWeight - 1) * 4) / 4; // Current weight minus 1, rounded to 0.25
                break;
            case 'GAIN_WEIGHT':
                // For weight gain: min = current weight + 1, max = current weight + 10
                minWeight = Math.round((currentDisplayWeight + 1) * 4) / 4; // Current weight plus 1, rounded to 0.25
                maxWeight = Math.min(isMetric ? 300 : 600, Math.round((currentDisplayWeight + 10) * 4) / 4 // Current weight plus 10, rounded to 0.25
                );
                break;
            case 'MAINTAIN':
                // For maintenance: no weight change allowed - set min and max to current weight
                minWeight = Math.round(currentDisplayWeight * 4) / 4;
                maxWeight = Math.round(currentDisplayWeight * 4) / 4;
                break;
            default:
                // Default fallback values
                return {
                    min: isMetric ? 30 : 60,
                    max: isMetric ? 300 : 600
                };
        }
        return {
            min: minWeight,
            max: maxWeight
        };
    };
    // Calculate smart default value based on weight goal
    const calculateDefaultWeight = ()=>{
        if (!state.weight || !state.weightGoal) return 0;
        const displayWeight = getCurrentWeightInDisplayUnit();
        // Calculate default based on goal
        switch(state.weightGoal){
            case 'MAINTAIN':
                return displayWeight; // Same as current weight
            case 'LOSE_WEIGHT':
                // Default to middle of the range (current weight - 5)
                return Math.round((displayWeight - 5) * 4) / 4;
            case 'GAIN_WEIGHT':
                // Default to middle of the range (current weight + 5)
                return Math.round((displayWeight + 5) * 4) / 4;
            default:
                return displayWeight;
        }
    };
    // Memoize min/max values to avoid recalculation on every render
    const { min: minWeight, max: maxWeight } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useMemo"])(()=>{
        return calculateMinMaxWeight();
    }, [
        state.weight,
        state.weightGoal,
        state.weightUnit,
        isMetric
    ]);
    const [desiredWeight, setDesiredWeight] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(()=>{
        // If we have a saved desiredWeight in context, use it
        if (state.desiredWeight && state.desiredWeight > 0) {
            return state.desiredWeight;
        }
        // Otherwise, calculate smart default
        return calculateDefaultWeight();
    });
    const [alert, setAlert] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])({
        show: false,
        type: '',
        message: ''
    });
    // Initialize component and set defaults
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEffect"])(()=>{
        // Handle redirects first
        if (state.isAuthChecked && state.isAuthenticated === false) {
            router.push('/register');
            return;
        }
        if (!state.weightGoal) {
            router.push('/weight-goal');
            return;
        }
        // Set current step
        if (state.currentStep !== 9) {
            updateStep(9);
        }
        // Initialize default value if not already set
        if (!state.desiredWeight || state.desiredWeight === 0) {
            const defaultWeight = calculateDefaultWeight();
            if (defaultWeight > 0) {
                setDesiredWeight(defaultWeight);
                updateField('desiredWeight', defaultWeight);
            }
        }
    }, [
        state.isAuthChecked,
        state.isAuthenticated,
        state.weightGoal,
        state.currentStep
    ]);
    // Handle unit changes and weight goal changes by recalculating weight if needed
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEffect"])(()=>{
        if (state.weight && state.weightGoal && desiredWeight > 0) {
            // Recalculate default when unit preference or weight goal changes
            const newDefault = calculateDefaultWeight();
            if (Math.abs(newDefault - desiredWeight) > (isMetric ? 1 : 2)) {
                setDesiredWeight(newDefault);
                updateField('desiredWeight', newDefault);
            }
        }
    }, [
        isMetric,
        state.weightGoal
    ]);
    // Ensure desired weight is within new min/max bounds when they change
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEffect"])(()=>{
        if (desiredWeight > 0 && (desiredWeight < minWeight || desiredWeight > maxWeight)) {
            // Clamp the desired weight to the new bounds
            const clampedWeight = Math.max(minWeight, Math.min(maxWeight, desiredWeight));
            setDesiredWeight(clampedWeight);
            updateField('desiredWeight', clampedWeight);
        }
    }, [
        minWeight,
        maxWeight,
        desiredWeight
    ]);
    const showAlert = (type, message)=>{
        setAlert({
            show: true,
            type,
            message
        });
    };
    const hideAlert = ()=>{
        setAlert({
            show: false,
            type: '',
            message: ''
        });
    };
    const handleWeightChange = (value)=>{
        setDesiredWeight(value);
        updateField('desiredWeight', value);
        hideAlert();
    };
    const validateWeight = ()=>{
        const currentDisplayWeight = getCurrentWeightInDisplayUnit();
        const goal = state.weightGoal;
        if (goal === 'LOSE_WEIGHT') {
            if (desiredWeight >= currentDisplayWeight) {
                return 'Desired weight must be less than current weight to lose weight.';
            }
            if (desiredWeight < currentDisplayWeight - 10) {
                return `Maximum weight loss allowed is 10 ${isMetric ? 'kg' : 'lbs'}.`;
            }
        }
        if (goal === 'GAIN_WEIGHT') {
            if (desiredWeight <= currentDisplayWeight) {
                return 'Desired weight must be greater than current weight to gain weight.';
            }
            if (desiredWeight > currentDisplayWeight + 10) {
                return `Maximum weight gain allowed is 10 ${isMetric ? 'kg' : 'lbs'}.`;
            }
        }
        if (goal === 'MAINTAIN') {
            // For maintenance, desired weight must be exactly the current weight
            if (Math.abs(desiredWeight - currentDisplayWeight) > 0.1) {
                return 'For maintenance, your desired weight should remain the same as your current weight.';
            }
        }
        return null; // No validation error
    };
    const handleContinue = (e)=>{
        e.preventDefault();
        if (!desiredWeight || desiredWeight <= 0) {
            showAlert('warning', 'Please enter your desired weight to continue.');
            return;
        }
        const validationError = validateWeight();
        if (validationError) {
            showAlert('warning', validationError);
            return;
        }
        if (isStepValid(9)) {
            updateStep(10);
            router.push('/workout-location');
        } else {
            showAlert('warning', 'Please ensure your desired weight is appropriate for your selected goal.');
        }
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Fragment"], {
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("section", {
            className: "auth-section",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "container",
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "row justify-content-center",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "col-lg-8",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "auth-logo text-center",
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                                        href: "/",
                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("img", {
                                            src: "/images/dark-logo.svg",
                                            alt: "Logo"
                                        }, void 0, false, {
                                            fileName: "[project]/app/(frontpage)/new-desired-weight/page.js",
                                            lineNumber: 249,
                                            columnNumber: 19
                                        }, this)
                                    }, void 0, false, {
                                        fileName: "[project]/app/(frontpage)/new-desired-weight/page.js",
                                        lineNumber: 248,
                                        columnNumber: 17
                                    }, this)
                                }, void 0, false, {
                                    fileName: "[project]/app/(frontpage)/new-desired-weight/page.js",
                                    lineNumber: 247,
                                    columnNumber: 15
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Components$2f$Alert$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                                    type: alert.type,
                                    message: alert.message,
                                    show: alert.show,
                                    onClose: hideAlert
                                }, void 0, false, {
                                    fileName: "[project]/app/(frontpage)/new-desired-weight/page.js",
                                    lineNumber: 253,
                                    columnNumber: 15
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "auth-cards new-desired-weight",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                            className: "text-uppercase mb-2",
                                            children: "Desired Weight"
                                        }, void 0, false, {
                                            fileName: "[project]/app/(frontpage)/new-desired-weight/page.js",
                                            lineNumber: 261,
                                            columnNumber: 17
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                                            className: "mb-2",
                                            children: "What is your desired weight?"
                                        }, void 0, false, {
                                            fileName: "[project]/app/(frontpage)/new-desired-weight/page.js",
                                            lineNumber: 262,
                                            columnNumber: 17
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                            children: [
                                                "Set your target weight based on your goal: ",
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("strong", {
                                                    children: state.weightGoal?.replace('_', ' ')
                                                }, void 0, false, {
                                                    fileName: "[project]/app/(frontpage)/new-desired-weight/page.js",
                                                    lineNumber: 263,
                                                    columnNumber: 63
                                                }, this)
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/app/(frontpage)/new-desired-weight/page.js",
                                            lineNumber: 263,
                                            columnNumber: 17
                                        }, this),
                                        state.weightGoal === 'MAINTAIN' && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "alert alert-info mt-3 mb-4",
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("strong", {
                                                    children: "Maintain Goal:"
                                                }, void 0, false, {
                                                    fileName: "[project]/app/(frontpage)/new-desired-weight/page.js",
                                                    lineNumber: 267,
                                                    columnNumber: 21
                                                }, this),
                                                " Your desired weight will remain the same as your current weight (",
                                                getCurrentWeightInDisplayUnit(),
                                                " ",
                                                isMetric ? 'kg' : 'lbs',
                                                ")."
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/app/(frontpage)/new-desired-weight/page.js",
                                            lineNumber: 266,
                                            columnNumber: 19
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("form", {
                                            onSubmit: handleContinue,
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Components$2f$DesiredWeightPicker$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                                                    weight: desiredWeight,
                                                    isMetric: isMetric,
                                                    onChange: handleWeightChange,
                                                    minWeight: minWeight,
                                                    maxWeight: maxWeight,
                                                    currentWeight: state.weight,
                                                    weightGoal: state.weightGoal,
                                                    currentWeightUnit: state.weightUnit,
                                                    disabled: state.weightGoal === 'MAINTAIN'
                                                }, void 0, false, {
                                                    fileName: "[project]/app/(frontpage)/new-desired-weight/page.js",
                                                    lineNumber: 273,
                                                    columnNumber: 19
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                    className: "text-center mt-2",
                                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                        type: "submit",
                                                        className: "custom-btn continue-btn",
                                                        disabled: !desiredWeight || desiredWeight <= 0,
                                                        children: "Continue"
                                                    }, void 0, false, {
                                                        fileName: "[project]/app/(frontpage)/new-desired-weight/page.js",
                                                        lineNumber: 286,
                                                        columnNumber: 21
                                                    }, this)
                                                }, void 0, false, {
                                                    fileName: "[project]/app/(frontpage)/new-desired-weight/page.js",
                                                    lineNumber: 285,
                                                    columnNumber: 19
                                                }, this)
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/app/(frontpage)/new-desired-weight/page.js",
                                            lineNumber: 271,
                                            columnNumber: 17
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/app/(frontpage)/new-desired-weight/page.js",
                                    lineNumber: 260,
                                    columnNumber: 15
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/app/(frontpage)/new-desired-weight/page.js",
                            lineNumber: 246,
                            columnNumber: 13
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/app/(frontpage)/new-desired-weight/page.js",
                        lineNumber: 245,
                        columnNumber: 11
                    }, this)
                }, void 0, false, {
                    fileName: "[project]/app/(frontpage)/new-desired-weight/page.js",
                    lineNumber: 244,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "auth-bttm",
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                children: [
                                    state.currentStep,
                                    "/"
                                ]
                            }, void 0, true, {
                                fileName: "[project]/app/(frontpage)/new-desired-weight/page.js",
                                lineNumber: 301,
                                columnNumber: 13
                            }, this),
                            " ",
                            state.totalSteps
                        ]
                    }, void 0, true, {
                        fileName: "[project]/app/(frontpage)/new-desired-weight/page.js",
                        lineNumber: 300,
                        columnNumber: 11
                    }, this)
                }, void 0, false, {
                    fileName: "[project]/app/(frontpage)/new-desired-weight/page.js",
                    lineNumber: 299,
                    columnNumber: 9
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/app/(frontpage)/new-desired-weight/page.js",
            lineNumber: 243,
            columnNumber: 7
        }, this)
    }, void 0, false);
}
const __TURBOPACK__default__export__ = DesiredWeightPage;
}),

};

//# sourceMappingURL=%5Broot-of-the-server%5D__4768393a._.js.map