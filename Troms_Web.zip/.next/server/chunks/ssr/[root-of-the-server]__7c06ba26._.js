module.exports = {

"[externals]/next/dist/server/app-render/work-async-storage.external.js [external] (next/dist/server/app-render/work-async-storage.external.js, cjs)": ((__turbopack_context__) => {

var { m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("next/dist/server/app-render/work-async-storage.external.js", () => require("next/dist/server/app-render/work-async-storage.external.js"));

module.exports = mod;
}}),
"[externals]/next/dist/server/app-render/action-async-storage.external.js [external] (next/dist/server/app-render/action-async-storage.external.js, cjs)": ((__turbopack_context__) => {

var { m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("next/dist/server/app-render/action-async-storage.external.js", () => require("next/dist/server/app-render/action-async-storage.external.js"));

module.exports = mod;
}}),
"[externals]/next/dist/server/app-render/work-unit-async-storage.external.js [external] (next/dist/server/app-render/work-unit-async-storage.external.js, cjs)": ((__turbopack_context__) => {

var { m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("next/dist/server/app-render/work-unit-async-storage.external.js", () => require("next/dist/server/app-render/work-unit-async-storage.external.js"));

module.exports = mod;
}}),
"[project]/lib/api.js [app-ssr] (ecmascript)": ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s({
    "BASE_URL": ()=>BASE_URL,
    "apiService": ()=>apiService
});
const BASE_URL = process.env.NEXT_PUBLIC_API_BASE_URL || "http://stage.tasksplan.com:5010/api/v1" || "http://localhost:5010/api/v1";
class ApiService {
    constructor(){
        this.baseURL = BASE_URL;
    }
    async request(endpoint, options = {}) {
        const url = `${this.baseURL}${endpoint}`;
        const config = {
            headers: {
                "Content-Type": "application/json",
                ...options.headers
            },
            ...options
        };
        if (config.body && typeof config.body !== "string") {
            config.body = JSON.stringify(config.body);
        }
        try {
            const response = await fetch(url, config);
            const data = await response.json();
            // if (!response.ok) {
            //   throw new Error(data.message || 'API request failed');
            // }
            return data;
        } catch (error) {
            console.error("API Error:", error);
            throw error;
        }
    }
    // Auth APIs
    async socialLogin(payload) {
        // Ensure required fields are present
        const requiredPayload = {
            email: payload.email,
            username: payload.username,
            platform: payload.platform,
            ...payload.userInfoId && {
                userInfoId: payload.userInfoId
            }
        };
        return this.request("/auth/social-login", {
            method: "POST",
            body: requiredPayload
        });
    }
    async createUserInfo(payload) {
        return this.request("/users/create-user-info", {
            method: "POST",
            body: payload
        });
    }
    // Equipment APIs
    async getEquipments() {
        return this.request("/workout/accesible-equipments");
    }
    // Food APIs
    async getCheatMeals() {
        return this.request("/food/cheat-meals-list");
    }
    async getAllergicFoodItems() {
        return this.request("/food/allergic-food-items-list");
    }
    async getDislikedFoodItems() {
        return this.request("/food/disliked-food-items-list");
    }
    // Injuries API
    async getInjuries() {
        return this.request("/workout/get-injuries-from-db");
    }
    //privacy-policy
    async privacyPolicy() {
        return this.request("/admin/privacy-policy");
    }
    //termsAndConditions
    async termsandconditions() {
        return this.request("/admin/terms-and-conditions");
    }
    // Subscription APIs
    async getSubscriptionPlans() {
        return this.request("/stripeWEB/get-subscription-plans");
    }
    async purchaseSubscription(priceId, paymentData) {
        console.log("paymentData", paymentData);
        return this.request(`/stripeWEB/purchase-subscription/${priceId}`, {
            method: "POST",
            body: paymentData
        });
    }
    // Razorpay APIs - Using existing Stripe endpoints with Razorpay payment data
    async createRazorpayPaymentMethod(paymentData) {
        // Simulate payment method creation for compatibility with existing backend
        return {
            success: true,
            paymentMethod: {
                id: `pm_razorpay_${Date.now()}`,
                type: "card",
                ...paymentData
            }
        };
    }
    async purchaseSubscriptionWithRazorpay(priceId, razorpayData) {
        // Use existing Stripe endpoint but with Razorpay payment data
        const paymentMethodData = {
            paymentMethodId: `pm_razorpay_${razorpayData.razorpay_payment_id}`,
            userInfoId: razorpayData.userInfoId,
            razorpayPaymentId: razorpayData.razorpay_payment_id,
            razorpayOrderId: razorpayData.razorpay_order_id,
            razorpaySignature: razorpayData.razorpay_signature
        };
        return this.request(`/stripeWEB/purchase-subscription/${priceId}`, {
            method: "POST",
            body: paymentMethodData
        });
    }
}
const apiService = new ApiService();
;
}),
"[project]/Components/Alert.js [app-ssr] (ecmascript)": ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s({
    "default": ()=>Alert
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react.js [app-ssr] (ecmascript)");
'use client';
;
;
function Alert({ type = 'info', message, show, onClose, autoClose = true, duration = 3000 }) {
    const [visible, setVisible] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(show);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEffect"])(()=>{
        setVisible(show);
        if (show && autoClose) {
            const timer = setTimeout(()=>{
                setVisible(false);
                if (onClose) onClose();
            }, duration);
            return ()=>clearTimeout(timer);
        }
    }, [
        show,
        autoClose,
        duration,
        onClose
    ]);
    if (!visible || !message) return null;
    const alertClasses = {
        success: 'alert-success',
        error: 'alert-danger',
        warning: 'alert-warning',
        info: 'alert-info'
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: `alert ${alertClasses[type]} alert-dismissible fade show`,
        role: "alert",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "d-flex align-items-center",
                children: [
                    type === 'success' && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                        className: "me-2",
                        children: "✅"
                    }, void 0, false, {
                        fileName: "[project]/Components/Alert.js",
                        lineNumber: 33,
                        columnNumber: 32
                    }, this),
                    type === 'error' && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                        className: "me-2",
                        children: "❌"
                    }, void 0, false, {
                        fileName: "[project]/Components/Alert.js",
                        lineNumber: 34,
                        columnNumber: 30
                    }, this),
                    type === 'warning' && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                        className: "me-2",
                        children: "⚠️"
                    }, void 0, false, {
                        fileName: "[project]/Components/Alert.js",
                        lineNumber: 35,
                        columnNumber: 32
                    }, this),
                    type === 'info' && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                        className: "me-2",
                        children: "ℹ️"
                    }, void 0, false, {
                        fileName: "[project]/Components/Alert.js",
                        lineNumber: 36,
                        columnNumber: 29
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                        children: message
                    }, void 0, false, {
                        fileName: "[project]/Components/Alert.js",
                        lineNumber: 37,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/Components/Alert.js",
                lineNumber: 32,
                columnNumber: 7
            }, this),
            onClose && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                type: "button",
                className: "btn-close",
                onClick: ()=>{
                    setVisible(false);
                    onClose();
                }
            }, void 0, false, {
                fileName: "[project]/Components/Alert.js",
                lineNumber: 40,
                columnNumber: 9
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/Components/Alert.js",
        lineNumber: 31,
        columnNumber: 5
    }, this);
}
}),
"[project]/app/(frontpage)/approach/page.js [app-ssr] (ecmascript)": ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s({
    "default": ()=>__TURBOPACK__default__export__
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/client/app-dir/link.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/navigation.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$context$2f$OnboardingContext$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/context/OnboardingContext.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$api$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/api.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Components$2f$Alert$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Components/Alert.js [app-ssr] (ecmascript)");
"use client";
;
;
;
;
;
;
;
function ApproachPage() {
    const router = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useRouter"])();
    const { state, setLoading, setError, updateStep, updateField, getFinalPayload } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$context$2f$OnboardingContext$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useOnboarding"])();
    const [alert, setAlert] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])({
        show: false,
        type: "",
        message: ""
    });
    const [isSubmitting, setIsSubmitting] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(false);
    const [isCompleted, setIsCompleted] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(false);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEffect"])(()=>{
        // Check for user data from localStorage if state is empty
        const checkUserData = ()=>{
            try {
                const savedState = localStorage.getItem("onboardingState");
                if (savedState) {
                    const parsedState = JSON.parse(savedState);
                    return parsedState.user || {};
                }
            } catch (error) {
                console.error("Error reading user data from localStorage:", error);
            }
            return {};
        };
        // Redirect if not authenticated
        if (state.isAuthChecked && state.isAuthenticated === false) {
            router.push("/register");
            return;
        }
        // Check if user email and username are present (from state or localStorage)
        const currentUser = state.user || {};
        const localStorageUser = checkUserData();
        const userEmail = currentUser.email || localStorageUser.email;
        const userUsername = currentUser.username || localStorageUser.username;
        if (!userEmail || !userUsername) {
            console.log("Missing user credentials - redirecting to register");
            showAlert("error", "User information is missing. Please register again.");
            setTimeout(()=>{
                router.push("/register");
            }, 2000);
            return;
        }
        // Check if all required fields are filled
        const requiredFields = [
            "gender",
            "dateOfBirth",
            "age",
            "trainingDays",
            "weight",
            "weightGoal",
            "desiredWeight",
            "workoutLocation",
            "selectedEquipments",
            "reachingGoals",
            "accomplish",
            "dietType",
            "cheatMealFoodItems",
            "cookingLevel",
            "allergicFoodItems",
            "dislikedFoodItems",
            "injuries"
        ];
        const missingFields = requiredFields.filter((field)=>{
            const value = state[field];
            if (Array.isArray(value)) return value.length === 0;
            return !value || value === "";
        });
        if (missingFields.length > 0) {
            console.log("Missing fields:", missingFields);
            showAlert("error", "Required information is missing. Redirecting to registration to complete setup...");
            setTimeout(()=>{
                router.push("/register");
            }, 2000);
            return;
        }
        // ✅ Only update step if not already set
        if (state.currentStep !== 23) {
            updateStep(23);
        }
    }, [
        state.isAuthChecked,
        state.isAuthenticated,
        state.currentStep,
        state.user
    ]);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEffect"])(()=>{
        if (state.currentStep === 23 && !isCompleted && !isSubmitting) {
            handleSubmitUserInfo();
        }
    }, [
        state.currentStep,
        isCompleted,
        isSubmitting
    ]);
    const showAlert = (type, message)=>{
        setAlert({
            show: true,
            type,
            message
        });
    };
    const hideAlert = ()=>{
        setAlert({
            show: false,
            type: "",
            message: ""
        });
    };
    const handleSubmitUserInfo = async ()=>{
        setIsSubmitting(true);
        setLoading(true);
        hideAlert();
        try {
            // Double-check user credentials before submission
            const currentUser = state.user || {};
            if (!currentUser.email || !currentUser.username) {
                showAlert("error", "User credentials are missing. Redirecting to registration...");
                setTimeout(()=>{
                    router.push("/register");
                }, 2000);
                return;
            }
            const payload = getFinalPayload();
            console.log("Submitting user data:", payload);
            const response = await __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$api$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["apiService"].createUserInfo(payload);
            if (response.success) {
                setIsCompleted(true);
                // Mark onboarding as complete
                updateField("needsOnboarding", false);
                // showAlert('success', 'Your profile has been created successfully!');
                updateField("user", {
                    ...state.user,
                    userInfoId: response.result.id
                });
                // Auto-redirect after success
                setTimeout(()=>{
                    router.push("/bmr");
                }, 2000);
            } else {
                // Check if error indicates authentication issues
                const errorMessage = response.message || "Failed to create profile. Please try again.";
                if (errorMessage.toLowerCase().includes("auth") || errorMessage.toLowerCase().includes("user") || errorMessage.toLowerCase().includes("credential")) {
                    showAlert("error", "Authentication failed. Please register again.");
                    setTimeout(()=>{
                        router.push("/register");
                    }, 2000);
                } else {
                    showAlert("error", errorMessage);
                }
            }
        } catch (error) {
            console.error("User info submission error:", error);
            // Check if it's a network error or authentication error
            if (error.message && (error.message.includes("401") || error.message.includes("403"))) {
                showAlert("error", "Authentication failed. Please register again.");
                setTimeout(()=>{
                    router.push("/register");
                }, 2000);
            } else {
                showAlert("error", "Failed to create profile. Please check your internet connection and try again.");
            }
        } finally{
            setLoading(false);
            setIsSubmitting(false);
        }
    };
    const handleContinue = ()=>{
        // Verify user credentials before proceeding
        const currentUser = state.user || {};
        if (!currentUser.email || !currentUser.username) {
            showAlert("error", "User credentials are missing. Redirecting to registration...");
            setTimeout(()=>{
                router.push("/register");
            }, 2000);
            return;
        }
        if (isCompleted) {
            updateStep(24);
            router.push("/bmr");
        } else {
            handleSubmitUserInfo();
        }
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Fragment"], {
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("section", {
            className: "auth-section",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "container",
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "row justify-content-center",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "col-lg-7",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "auth-logo text-center",
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                                        href: "/",
                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("img", {
                                            src: "/images/dark-logo.svg",
                                            alt: "Logo"
                                        }, void 0, false, {
                                            fileName: "[project]/app/(frontpage)/approach/page.js",
                                            lineNumber: 233,
                                            columnNumber: 19
                                        }, this)
                                    }, void 0, false, {
                                        fileName: "[project]/app/(frontpage)/approach/page.js",
                                        lineNumber: 232,
                                        columnNumber: 17
                                    }, this)
                                }, void 0, false, {
                                    fileName: "[project]/app/(frontpage)/approach/page.js",
                                    lineNumber: 231,
                                    columnNumber: 15
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Components$2f$Alert$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                                    type: alert.type,
                                    message: alert.message,
                                    show: alert.show,
                                    onClose: hideAlert
                                }, void 0, false, {
                                    fileName: "[project]/app/(frontpage)/approach/page.js",
                                    lineNumber: 237,
                                    columnNumber: 15
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "auth-cards food",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                            className: "text-uppercase mb-5",
                                            children: "Approach"
                                        }, void 0, false, {
                                            fileName: "[project]/app/(frontpage)/approach/page.js",
                                            lineNumber: 245,
                                            columnNumber: 17
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "text-center mt-3 mb-3",
                                            children: isCompleted ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("img", {
                                                src: "/images/check-mark.svg",
                                                alt: "Success"
                                            }, void 0, false, {
                                                fileName: "[project]/app/(frontpage)/approach/page.js",
                                                lineNumber: 249,
                                                columnNumber: 21
                                            }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("img", {
                                                src: "/images/loader.svg",
                                                className: "bmr-img",
                                                alt: "BMR Graph"
                                            }, void 0, false, {
                                                fileName: "[project]/app/(frontpage)/approach/page.js",
                                                lineNumber: 251,
                                                columnNumber: 21
                                            }, this)
                                        }, void 0, false, {
                                            fileName: "[project]/app/(frontpage)/approach/page.js",
                                            lineNumber: 247,
                                            columnNumber: 17
                                        }, this),
                                        isSubmitting && !isCompleted ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "text-center",
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                                                    className: "mb-4",
                                                    children: "Creating Your Profile..."
                                                }, void 0, false, {
                                                    fileName: "[project]/app/(frontpage)/approach/page.js",
                                                    lineNumber: 259,
                                                    columnNumber: 21
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                    children: "Please wait while we process your information and create your personalized fitness plan."
                                                }, void 0, false, {
                                                    fileName: "[project]/app/(frontpage)/approach/page.js",
                                                    lineNumber: 260,
                                                    columnNumber: 21
                                                }, this)
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/app/(frontpage)/approach/page.js",
                                            lineNumber: 258,
                                            columnNumber: 19
                                        }, this) : isCompleted ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "text-center",
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                                                    className: "mb-4",
                                                    children: "Thank you for your approach!"
                                                }, void 0, false, {
                                                    fileName: "[project]/app/(frontpage)/approach/page.js",
                                                    lineNumber: 267,
                                                    columnNumber: 21
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                    children: [
                                                        "We promise to always keep your personal ",
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("br", {}, void 0, false, {
                                                            fileName: "[project]/app/(frontpage)/approach/page.js",
                                                            lineNumber: 269,
                                                            columnNumber: 63
                                                        }, this),
                                                        " ",
                                                        "information's private and secure"
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/app/(frontpage)/approach/page.js",
                                                    lineNumber: 268,
                                                    columnNumber: 21
                                                }, this)
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/app/(frontpage)/approach/page.js",
                                            lineNumber: 266,
                                            columnNumber: 19
                                        }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "text-center",
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                                                    className: "mb-4",
                                                    children: "Submitting Your Information..."
                                                }, void 0, false, {
                                                    fileName: "[project]/app/(frontpage)/approach/page.js",
                                                    lineNumber: 275,
                                                    columnNumber: 21
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                    children: "Please wait while we create your personalized fitness profile."
                                                }, void 0, false, {
                                                    fileName: "[project]/app/(frontpage)/approach/page.js",
                                                    lineNumber: 276,
                                                    columnNumber: 21
                                                }, this)
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/app/(frontpage)/approach/page.js",
                                            lineNumber: 274,
                                            columnNumber: 19
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "text-center mt-3",
                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                onClick: handleContinue,
                                                className: "custom-btn continue-btn",
                                                disabled: isSubmitting || state.loading,
                                                children: isSubmitting || state.loading ? "Processing..." : "Continue"
                                            }, void 0, false, {
                                                fileName: "[project]/app/(frontpage)/approach/page.js",
                                                lineNumber: 284,
                                                columnNumber: 19
                                            }, this)
                                        }, void 0, false, {
                                            fileName: "[project]/app/(frontpage)/approach/page.js",
                                            lineNumber: 283,
                                            columnNumber: 17
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/app/(frontpage)/approach/page.js",
                                    lineNumber: 244,
                                    columnNumber: 15
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/app/(frontpage)/approach/page.js",
                            lineNumber: 230,
                            columnNumber: 13
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/app/(frontpage)/approach/page.js",
                        lineNumber: 229,
                        columnNumber: 11
                    }, this)
                }, void 0, false, {
                    fileName: "[project]/app/(frontpage)/approach/page.js",
                    lineNumber: 228,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "auth-bttm",
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                children: [
                                    state.currentStep,
                                    "/"
                                ]
                            }, void 0, true, {
                                fileName: "[project]/app/(frontpage)/approach/page.js",
                                lineNumber: 300,
                                columnNumber: 13
                            }, this),
                            " ",
                            state.totalSteps
                        ]
                    }, void 0, true, {
                        fileName: "[project]/app/(frontpage)/approach/page.js",
                        lineNumber: 299,
                        columnNumber: 11
                    }, this)
                }, void 0, false, {
                    fileName: "[project]/app/(frontpage)/approach/page.js",
                    lineNumber: 298,
                    columnNumber: 9
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/app/(frontpage)/approach/page.js",
            lineNumber: 227,
            columnNumber: 7
        }, this)
    }, void 0, false);
}
const __TURBOPACK__default__export__ = ApproachPage;
}),

};

//# sourceMappingURL=%5Broot-of-the-server%5D__7c06ba26._.js.map